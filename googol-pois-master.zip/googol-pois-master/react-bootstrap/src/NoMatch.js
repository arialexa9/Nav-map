import React from 'react'

export const NoMatch = () => (
    <div>
        <h1>404 page not found</h1>
    </div>
)

